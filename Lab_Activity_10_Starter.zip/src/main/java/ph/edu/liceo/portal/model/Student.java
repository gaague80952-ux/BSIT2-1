package ph.edu.liceo.portal.model;

/**
 * MODEL: one student account.
 *
 * This class must NOT import anything from javafx.scene.
 * It only holds data about a student - no buttons, no labels.
 */
public class Student {

    // ------------------------------------------------------------------
    // TODO 1: Declare six private final fields:
    //         studentNo (String), password (String), fullName (String),
    //         course (String), yearLevel (int), email (String)
    // ------------------------------------------------------------------


    // ------------------------------------------------------------------
    // TODO 2: Write the constructor. It takes the six values above, in the
    //         same order, and copies each one into its field with "this.".
    //
    //         public Student(String studentNo, String password, String fullName,
    //                        String course, int yearLevel, String email) { ... }
    // ------------------------------------------------------------------


    // ------------------------------------------------------------------
    // TODO 3: Write the six getters. The signatures are already here -
    //         you only need to write the return statement inside each one.
    // ------------------------------------------------------------------
    public String getStudentNo() {
        // TODO 3a
    }

    public String getPassword() {
        // TODO 3b
    }

    public String getFullName() {
        // TODO 3c
    }

    public String getCourse() {
        // TODO 3d
    }

    public int getYearLevel() {
        // TODO 3e
    }

    public String getEmail() {
        // TODO 3f
    }

    /**
     * Already written for you. It uses two of your getters, so it will only
     * work once TODO 3 is done.
     *
     * Example result: "BS Information Technology  -  Year 3"
     */
    public String getCourseAndYear() {
        return getCourse() + "  -  Year " + getYearLevel();
    }
}
